// =====================================================================
// KONFIGURASI ALAMAT SITUS (BASE URL)
// =====================================================================
// Ganti nilai di bawah ini dengan alamat tempat situs ini di-hosting,
// TANPA tanda "/" di akhir. Setelah diubah, seluruh QR code di 511
// halaman kartu siswa akan otomatis mengarah ke alamat yang benar —
// tidak perlu generate ulang halaman satu per satu.
//
// Contoh:
//   Jika situs diakses di https://nisndata.sekaradi.sch.id/
//   maka isi:  const SITE_BASE_URL = "https://nisndata.sekaradi.sch.id";
//
//   Jika situs dihosting di GitHub Pages dengan nama repo "kartu-siswa"
//   di akun "sekaradi", maka isi:
//   const SITE_BASE_URL = "https://sekaradi.github.io/kartu-siswa";
// =====================================================================

const SITE_BASE_URL = "https://ganti-dengan-domain-anda.com";
