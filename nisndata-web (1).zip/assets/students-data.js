const STUDENTS = [
  {
    "id": 1,
    "nama": "ADHISTI BHUMI PRADANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 2,
    "nama": "AEZAWAL MUADZ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 3,
    "nama": "ALANNA EMILY SUSANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 4,
    "nama": "ALECIO ATHATSANY IRFANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 5,
    "nama": "ARSYILA HANA AZZAIDA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 6,
    "nama": "ARUNG DANUDIRJA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 7,
    "nama": "BAIHAQI WATAN IBRAHIMOVIC",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 8,
    "nama": "CIKAL AISHA RESPATY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 9,
    "nama": "DIYA KHAIRAH NADHIFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 10,
    "nama": "ENZO HIRO MAHESA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 11,
    "nama": "FIRAS AIMAN YUDHISTIRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 12,
    "nama": "GHEA MALIKA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 13,
    "nama": "HAFSHOH QOTHROTUN NADA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 14,
    "nama": "HAVIZHAN DHIYAULHAQ ENZO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 15,
    "nama": "JANICE AZURA ULRICA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 16,
    "nama": "JASMINE ZEA PUTRI LAKSMANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 17,
    "nama": "KAMRAN ALBY KAMIL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 18,
    "nama": "KAYLA DZAKIRA ANAVI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 19,
    "nama": "KEENAR ALULA ALMAHYRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 20,
    "nama": "KHALID DWI PRADIPTA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 21,
    "nama": "KHAZATA AFSHEEN ALLYSA SANTOSO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 22,
    "nama": "MUHAMMAD SYAHRIR ALISYAHBANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 23,
    "nama": "NARENDRA SHAQUILLE ESVANDIAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 24,
    "nama": "RAIHANAH FAHRIANI MARYAM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 25,
    "nama": "SAKHA NANDANA FAUZI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 26,
    "nama": "SASIKIRANA ALISHA AFANDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 27,
    "nama": "WAHYUDA PUTRA PRATAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 28,
    "nama": "ZEINECHA DANISWARA JATI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I A"
  },
  {
    "id": 29,
    "nama": "AKSARA RAYYANKA SHAQUILLE ALTEZZA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 30,
    "nama": "ANNISA SEPTIANI PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 31,
    "nama": "AZKIYA SRI NAMI PUTRI SARAGIH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 32,
    "nama": "ELVANO KHAIZURAN ARDANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 33,
    "nama": "DHIAJENG MEDINA AGUNG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 34,
    "nama": "FATIMAH YUMNA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 35,
    "nama": "FIDI ALTHAF VIRENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 36,
    "nama": "GAVYN ALTHAFFU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 37,
    "nama": "HIBRAN ARMAUNA IBRAHIM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 38,
    "nama": "JOURDAN MUHAMMAD ADLINURRAHMAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 39,
    "nama": "KHAIRINA NAFIZA BILQIS",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 40,
    "nama": "KHAIRRAZKY HISYAM ALFARIZ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 41,
    "nama": "KHALISA AZALIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 42,
    "nama": "KYARA ALOVA SHAKEERA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 43,
    "nama": "LUBNA KHANZA ALAYDRUS",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 44,
    "nama": "MAHAWIRA GANDHIBIRU WASUPATI P. A",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 45,
    "nama": "MUHAMMAD AMMAR EFENDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 46,
    "nama": "MUHAMMAD AZKA MAULANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 47,
    "nama": "MUHAMMAD NIZAM ARRASYID",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 48,
    "nama": "NARA ANNASSYA SAILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 49,
    "nama": "PANJI ANTASSENA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 50,
    "nama": "RAYYAN ABQARY ALFARIZQI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 51,
    "nama": "REZVAN RAFFASYA YUDHANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 52,
    "nama": "SHAMMER HUSAIN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 53,
    "nama": "SHANKARA ATHARRAZKA GHOFUR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 54,
    "nama": "TSABINA AYU ASSYFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I B"
  },
  {
    "id": 55,
    "nama": "AKSARA KALENDRA PUTRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 56,
    "nama": "ARINDA ANAMI ARFAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 57,
    "nama": "ASHRAF ILYAS HAKIMI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 58,
    "nama": "ATASYA MAFAZA HILYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 59,
    "nama": "BAGAS ANUGRAH WIJAYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 60,
    "nama": "DEVINYA PUTRI SIREGAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 61,
    "nama": "DIANDRA PUTRI BRILLIANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 62,
    "nama": "DZARA ALANNA REFINDYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 63,
    "nama": "FAWWAZ JANUAR PRATAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 64,
    "nama": "FRILLIA AYUNA LAKEESHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 65,
    "nama": "GHINA NARAYA ANINDITA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 66,
    "nama": "HAFIDZH TAMIM AL FAISAL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 67,
    "nama": "HASSAN AFIF MUSYAFFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 68,
    "nama": "INAYA LAILA RAMADHANIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 69,
    "nama": "JONAS MATONDANG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 70,
    "nama": "KEIRA NATASHA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 71,
    "nama": "LIESA CIARA WANGSADIRHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 72,
    "nama": "MUHAMMAD KENZIE ARRASYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 73,
    "nama": "MUHAMMAD SAHL IBRAHIM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 74,
    "nama": "MUHAMMAD SYAKIR ATHARRAZKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 75,
    "nama": "MUHAMMAD ZEIN HERMAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 76,
    "nama": "MUZAKKI NAFIZA HIBBAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 77,
    "nama": "NI NENGAH NAAVA UMA DEWI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 78,
    "nama": "NURSYIFA AZZAHRA PERMADI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 79,
    "nama": "RATU ALEENA ZAHRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 80,
    "nama": "REEVHANNE BHANURASHMI KURNIAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 81,
    "nama": "SAGARA BIRRU ABDILLAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 82,
    "nama": "WAFDA ARSENIO ABDULKARIM SIAGIAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS I C"
  },
  {
    "id": 83,
    "nama": "ADIBAH SHANUM FATHARANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 84,
    "nama": "AISYABILLA MYESHA AFSHEENA K.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 85,
    "nama": "ALFAREZEL NOVIAN KSYAVANI SETIANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 86,
    "nama": "ARKANA CANDRADITYA HARTANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 87,
    "nama": "ARSENIO MANGGALA WISTARA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 88,
    "nama": "AYESHA KINARA ABDILLAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 89,
    "nama": "AZKIA SALSABILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 90,
    "nama": "AZURA MIKAYLA SALSABILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 91,
    "nama": "CLEMIRA ALMAHYRA RAHMADHIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 92,
    "nama": "DANIKA GALUH SANTIKARANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 93,
    "nama": "DAVIE AL FAEYZA ABIZARD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 94,
    "nama": "EMBUN NAYRA DRAJAT",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 95,
    "nama": "GENDIEZ SHAQUEENARAVA MULYO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 96,
    "nama": "HAIKAL PUTRA TAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 97,
    "nama": "HAMDAN MUFLIH AL FAISAL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 98,
    "nama": "HAMZAH MUFID AL FAISAL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 99,
    "nama": "KENDRA HARDI ARKANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 100,
    "nama": "KENZO IHWANI LEE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 101,
    "nama": "LUTHFI HERLAMBANG DIRGANTARA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 102,
    "nama": "MAHESWARI NUHA RAFANDA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 103,
    "nama": "MUHAMMAD GHAFFAR AL - MUSYAFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 104,
    "nama": "MUHAMMAD NOVAL SHADAT",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 105,
    "nama": "NAJMA MYSHA SHAREEN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 106,
    "nama": "NAURA KAMILA CAHYA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 107,
    "nama": "RAEKY ATHALLA KENZIE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 108,
    "nama": "RAZQA MUFLIH AHMAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 109,
    "nama": "SAFFANAH AZZAHRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 110,
    "nama": "SAGA ANAQI CIKMAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 111,
    "nama": "SHAFA ALEXANDRIA RENATA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 112,
    "nama": "VALDO ZABRAN SAPUTRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II A"
  },
  {
    "id": 113,
    "nama": "AMEERA SOFIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 114,
    "nama": "ANINDYA FATHIYA PUTRI BURHANUDIN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 115,
    "nama": "ANNASYA RAISHA ISMAIL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 116,
    "nama": "ARAZQY NOVERIAL AHMAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 117,
    "nama": "ARFAN ZAVIER RAMADHAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 118,
    "nama": "ARIENDRA KAHANITAMI FAHIM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 119,
    "nama": "ARKA FENGFU SATRIO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 120,
    "nama": "ARKANA BISMA HANAFI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 121,
    "nama": "ATHALLA ANANDA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 122,
    "nama": "AURORA ADENAYA AHMAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 123,
    "nama": "AYANA FATHIYATURRAHMA AISHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 124,
    "nama": "AZKA MAULANA FADHIL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 125,
    "nama": "BELLALUNA ADEEVA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 126,
    "nama": "EZRA ADELLIO KAMIL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 127,
    "nama": "FARADIBA ALTHAFUNNISA ADZANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 128,
    "nama": "HASYA MAHIRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 129,
    "nama": "KEIKA HANANIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 130,
    "nama": "MAUDYA IQLIMA RAMDHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 131,
    "nama": "MUHAMMAD DAFFA ABQARY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 132,
    "nama": "MUHAMMAD KAIFA AL FATIH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 133,
    "nama": "MUHAMMAD KAMAYEL MECCA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 134,
    "nama": "NALADHIPA HALONA SYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 135,
    "nama": "NAYAKA DAMAREZVAN ALHANAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 136,
    "nama": "QIANA PUTRI RAYA IRAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 137,
    "nama": "RAFANDRA AQLAN LAZUARDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 138,
    "nama": "SAKHA IHZA KAYANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 139,
    "nama": "UMAR RAFFAZA SATWIKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 140,
    "nama": "VALEIA JINGGA RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 141,
    "nama": "ZAYN ARZAN RAMADHAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II B"
  },
  {
    "id": 142,
    "nama": "ARSYA ZIO FAHREZA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 143,
    "nama": "ARVINO MAUZA SIMANJUNTAK",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 144,
    "nama": "AUREA BELLVANIA LATISHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 145,
    "nama": "AZALEA ALFARIZKI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 146,
    "nama": "BRIANA ACHIERA SIMATUPANG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 147,
    "nama": "DAVIN ELANG GIANES SIPAHUTAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 148,
    "nama": "DAVINA ABIGAIL RIMPAS TARULI S.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 149,
    "nama": "GINA FAHIRA AHMAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 150,
    "nama": "GIRI MUHAMMAD HAKIKI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 151,
    "nama": "HELSA VANIA UTOMO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 152,
    "nama": "JAVISTA KYRIE NUNNUHITU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 153,
    "nama": "JIBRIL FATIH JAYADIREJA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 154,
    "nama": "KIMI KANAYA HABIBIE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 155,
    "nama": "LANA ATHIRA FREISSY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 156,
    "nama": "LATIF ZEIN ARTHUR SIFREDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 157,
    "nama": "LIANDRA EDSEL KHARISMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 158,
    "nama": "MIKHAYLA ADALINE KURNIAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 159,
    "nama": "MOHAMMAD GIBRAN AL FATIH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 160,
    "nama": "MUHAMMAD FADLI EFENDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 161,
    "nama": "NEHEMIA GIORGINO SAUT GANDA S.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 162,
    "nama": "NURAFNI PUTRI MAULIDA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 163,
    "nama": "OTNIEL LUCIO SIANTURI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 164,
    "nama": "QIYANA FAQEEHA ASSILMI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 165,
    "nama": "RAFFA ADINATA NUR RENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 166,
    "nama": "RATU ARFINADI RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 167,
    "nama": "RIZA TAMA GRIANTIARDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 168,
    "nama": "SALMA FREDELLA KIRANIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 169,
    "nama": "VANESSA AURELIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 170,
    "nama": "VIOLINA AZZAHRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 171,
    "nama": "XAVIER XL ELY REKEN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS II C"
  },
  {
    "id": 172,
    "nama": "AFAF NASIR MAHFUD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 173,
    "nama": "AKMA DEWANTA KAVINDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 174,
    "nama": "ALARIC VIRENDRA ZEROUN SITUMORANG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 175,
    "nama": "ALMEERA AZZAHRA ALFATHUNISSA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 176,
    "nama": "ANDIKA HAZMI WIRA ALFARIZKI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 177,
    "nama": "ARFAN DZAKA ARIADI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 178,
    "nama": "ARSYLA MALAEKA ARFAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 179,
    "nama": "AYESHA JENNAHARA RINALDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 180,
    "nama": "AZQIARA ANNAYA TULAR SEKTIYAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 181,
    "nama": "AZZAM ASYAM PRAMUDYANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 182,
    "nama": "BANAFSHA YUFI MUSTAGHFIROH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 183,
    "nama": "DANENDRA HANIF LEICHHARDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 184,
    "nama": "HERO ACHMAD AFKARIAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 185,
    "nama": "JASMINE GHANIA AL-KARIMAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 186,
    "nama": "KHANZA AURELIA AZKADINA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 187,
    "nama": "KINANDARI AMEERA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 188,
    "nama": "KIRANA ADIFA ALMAHYRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 189,
    "nama": "LINGGA MAHADI SAKA UTOMO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 190,
    "nama": "MICHELLE AYREEN CHANDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 191,
    "nama": "MOCHAMMAD RIZKY FADILAH JOESOEF",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 192,
    "nama": "MUHAMMAD SYAHIR FAIQ A.F",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 193,
    "nama": "NADHIF DZAKI ATTAQI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 194,
    "nama": "NARENDRA RAFIF LEICHHARDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 195,
    "nama": "NAYAKA RAKHA IZZ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 196,
    "nama": "NOUREEN ALESHAGANES REZEQITINIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 197,
    "nama": "RAFATHAR HARIZKY RAMADHAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 198,
    "nama": "SHABIYYA SHAYLAGHANIS ANWAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 199,
    "nama": "SHAREEN PUTRI UTOMO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III A"
  },
  {
    "id": 200,
    "nama": "AL DEVARO BARRA EVANO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 201,
    "nama": "ALDRIC ZAFLAN RAFFASYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 202,
    "nama": "ALIFIANDRA GHIFFARY ALBAAQI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 203,
    "nama": "ALISHA MAYA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 204,
    "nama": "ANDI ANDHRA AMRY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 205,
    "nama": "ARBA ISRA ABIUKHOYIN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 206,
    "nama": "ATHALLA RAKHA ARIFILAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 207,
    "nama": "ATHAR ALFATIH PERMANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 208,
    "nama": "AYRA AYUDIA NAIRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 209,
    "nama": "AZKAYRA CHANTIQA HARDIANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 210,
    "nama": "BASTIAN RENDRA SACHDEV",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 211,
    "nama": "CHELSEA DILOVA NOVENSIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 212,
    "nama": "DINA SETYANINGRUM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 213,
    "nama": "GHALI ADIKA MANGGALA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 214,
    "nama": "JIHAN SALSABILA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 215,
    "nama": "KINANDITA GAURI SEZHAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 216,
    "nama": "KIRANIA MEDINA ABADI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 217,
    "nama": "MALIQI ZAYN ALSYAZANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 218,
    "nama": "MUHAMMAD AFFAN ZULKARNAIN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 219,
    "nama": "MUHAMMAD FAUZAN AZHIMAA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 220,
    "nama": "MUHAMMAD HABIBI ABRISAM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 221,
    "nama": "MUHAMMAD ZAFRAN SYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 222,
    "nama": "RADEVA TRIS SAPUTRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 223,
    "nama": "RIFFIAR XAVIER ARDYANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 224,
    "nama": "RUMAISHA HASNA AZKAYRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 225,
    "nama": "SULTAN HAKI ZARKASIH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III B"
  },
  {
    "id": 226,
    "nama": "AKIF DZIKRULLAH HAMID",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 227,
    "nama": "ALFAREZEL SAESA RAFISQY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 228,
    "nama": "ANESSA TESALONIKA SIMANJUNTAK",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 229,
    "nama": "ARSYILA ALLEA RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 230,
    "nama": "AYRA MARDIAH APRIANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 231,
    "nama": "AZEEMA RUBY MALAYEKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 232,
    "nama": "ELSHANUM ALMAHYRA GUNAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 233,
    "nama": "GHIFARY UMAR YUSUF",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 234,
    "nama": "GIANDRA ZUMAR AFFANDI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 235,
    "nama": "JESLYN ANGELINA AURORA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 236,
    "nama": "JIHAN AULIA SHAQILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 237,
    "nama": "JORGHI FRIZZY LIANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 238,
    "nama": "KANISHA IZZATUL FAZIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 239,
    "nama": "KENNETH ALOYSIUS SENDORO W.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 240,
    "nama": "KENZIE GAVRIEL SALHUTERU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 241,
    "nama": "KENZOE RAFFAEL SALHUTERU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 242,
    "nama": "LATHIF INDRIANTO MASKURI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 243,
    "nama": "LORIN AZIMA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 244,
    "nama": "MARVIN GOTTA PURBA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 245,
    "nama": "NAFISAH AIZA SALMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 246,
    "nama": "NAGITA VIVI AOWLIYA UTAMI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 247,
    "nama": "NARAYAN PUTRA PRADIPTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 248,
    "nama": "NURI ALFIA SEPTIANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 249,
    "nama": "QUEENA AZZAHRA FAHLEFI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 250,
    "nama": "REYNAND RAFANDRA ARAJNA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 251,
    "nama": "RIFAT ABID ABYANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 252,
    "nama": "VIOLETA ARUMI ARFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS III C"
  },
  {
    "id": 253,
    "nama": "ADZKIERA AZALEA IRFANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 254,
    "nama": "AFIAA RAHMA NAFISAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 255,
    "nama": "AL FATIH DAFI FILHAQ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 256,
    "nama": "AMMAR RIZKI DERMAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 257,
    "nama": "ANANDA SHAQUEENA HUMAIRA F.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 258,
    "nama": "ARFAN MIYAZ AHMAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 259,
    "nama": "ARSYILA MANZA KINARA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 260,
    "nama": "ARVINO GILANG ABHISEVA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 261,
    "nama": "ATHALLA MALIQ HARDIANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 262,
    "nama": "AYUMI ANINDYA FARIEFADILLA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 263,
    "nama": "AZALEA AYSHA FAIHA YUONO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 264,
    "nama": "DHINARA SYAKIA HANDRIANTY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 265,
    "nama": "EL SAFAR RACHMAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 266,
    "nama": "GALENDRA ARSENIO UTOMO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 267,
    "nama": "GIBRAN AHNAF RAJENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 268,
    "nama": "JOURDAN FRIZZY LIANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 269,
    "nama": "KENZIE ADYATAMA LIU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 270,
    "nama": "KEVIN AZKA PRATAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 271,
    "nama": "KHALISA AZKADINA SHAFIYYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 272,
    "nama": "KYAN ZIDANE SYAILENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 273,
    "nama": "MAKAILA RATU HARAHAP",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 274,
    "nama": "MARYAM HUWAIDA FADHILAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 275,
    "nama": "MOHAMAD FABIAN MAUZA WIJAYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 276,
    "nama": "MUHAMMAD RAFARDHAN A.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 277,
    "nama": "MUTIA RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 278,
    "nama": "NADA AISYAH SALSABILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 279,
    "nama": "NAZWA KARIMAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 280,
    "nama": "RHEA AZALIA PRASETYO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 281,
    "nama": "RUMAISHA ANDRIANY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV A"
  },
  {
    "id": 282,
    "nama": "ALISKA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 283,
    "nama": "ALMAIRA DWI YASMIN QURRATU A.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 284,
    "nama": "AMRAAND ZEHAN PANDYADHYRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 285,
    "nama": "ANDIRA KIRANA WIJAYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 286,
    "nama": "ARKA DIRGANTARA TAUCHID",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 287,
    "nama": "ARRAFI KHALIF AHMAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 288,
    "nama": "AUKIV ERLAYAS SITEPU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 289,
    "nama": "AZMYA ARSYANA EL FATAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 290,
    "nama": "FITRI RAHMADANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 291,
    "nama": "GHASHIA NADIRA ROSE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 292,
    "nama": "GIBRAN AL ABRISAM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 293,
    "nama": "GILANG ARSAKHA ROCHIM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 294,
    "nama": "GWEEN NADHEERA PUTRI ARDANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 295,
    "nama": "IBNU KHALIF FAKHRUDDIN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 296,
    "nama": "KAIVAN LIANDRA ARSHAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 297,
    "nama": "KEYZIA SHAQUEENA ALFIRA SANTOSO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 298,
    "nama": "KIANDRA ANAIA HARZA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 299,
    "nama": "MIKHAYLA SYAKIRA WIJANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 300,
    "nama": "MISHAEL ZAINA ALESHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 301,
    "nama": "MOCHAMMAD EL AZZAM A.F.P",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 302,
    "nama": "MUHAMMAD RAYHAN ALFATIH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 303,
    "nama": "MYLO ALWALID IBRAHIMSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 304,
    "nama": "NAILA SYAHIDAH FATIMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 305,
    "nama": "QUINZA SHAKILA RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 306,
    "nama": "RAIA NABIL MUSTAFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 307,
    "nama": "RAKHA KAYANA DANENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 308,
    "nama": "RARA ANINDYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 309,
    "nama": "TEUKU ASAD SAKHIY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 310,
    "nama": "ZIVARA QIANNA ALLEA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV B"
  },
  {
    "id": 311,
    "nama": "ADZKIYA MALAYEKA FAJAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 312,
    "nama": "AHLAN SHEKA OLIVIO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 313,
    "nama": "ALFA DAOMARA LAWOLO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 314,
    "nama": "ALVARO NATANAEL SINAGA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 315,
    "nama": "ANDARU GIRI SUSANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 316,
    "nama": "ARSILA NASYWA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 317,
    "nama": "DEFKIAN PUTRA MELDIANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 318,
    "nama": "FATIMAH AZZAHRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 319,
    "nama": "GITA PERMATA MAHESWARI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 320,
    "nama": "IGNATIUS YORIANGGA PERWIRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 321,
    "nama": "JEANNE KEYNARA ALARICE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 322,
    "nama": "LOUISA ROSABELLA HARIANJA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 323,
    "nama": "MAZIYYA HILYA AULIYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 324,
    "nama": "MUHAMMAD AL FATIH RAFAEYZA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 325,
    "nama": "MUHAMMAD ARKAAN ALFARIZQI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 326,
    "nama": "MUHAMMAD ARYA CHANDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 327,
    "nama": "MYSHA INARA CHIYANUMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 328,
    "nama": "NADHEERA MISHALL ALFATHUNISSA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 329,
    "nama": "NANDITO BRANATA WISMAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 330,
    "nama": "NIARA DELICIA WIJAYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 331,
    "nama": "RAINA AZALEA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 332,
    "nama": "REYHAN ALFARIZ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 333,
    "nama": "SABIA MAESA AGIFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 334,
    "nama": "SALWA SHALSABILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 335,
    "nama": "SEPTRIANI PUTRI SIHALOHO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 336,
    "nama": "SHALOM HASIHOLAN GAMALIEL S.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 337,
    "nama": "SYAUQI REI CIKMAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 338,
    "nama": "UNING SRI NGESTI SAWIJI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 339,
    "nama": "ZYO RAHANDIKA FADHIL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS IV C"
  },
  {
    "id": 340,
    "nama": "ADELIA NAFIAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 341,
    "nama": "AKILA KHALIQA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 342,
    "nama": "ALESHA AZZAHRA ALFATHUNISSA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 343,
    "nama": "ALIF ZIYAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 344,
    "nama": "ALUBNA KIRANJANI ANWAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 345,
    "nama": "ALYSSA FAJRINA ARIEFIANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 346,
    "nama": "AUFA VELFIRA RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 347,
    "nama": "AYSHA KIRANA UTOMO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 348,
    "nama": "ELVIRA DEPHIA VELITA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 349,
    "nama": "FATIMAH ANDRIANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 350,
    "nama": "HAVEA ABRSIAMPUTRA HARYANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 351,
    "nama": "HELMI WIRANATA KUSUMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 352,
    "nama": "KENZIE RIZQY PRATAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 353,
    "nama": "KIANO RAFASHA HARDY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 354,
    "nama": "MARYNA ALTHEA ANG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 355,
    "nama": "MUHAMMAD ALFARIZKY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 356,
    "nama": "MUHAMMAD AYDAN TSAQIB",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 357,
    "nama": "MUHAMMAD AYMAR TSABIT",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 358,
    "nama": "MUHAMMAD RYUGA DAVANKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 359,
    "nama": "NAFISA KHALIFATUL HUSNA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 360,
    "nama": "NUR KHALISAH PUTRI ANDURRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 361,
    "nama": "RAYYAN ALFIAN SYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 362,
    "nama": "SABRINA APRLIA HIBBAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 363,
    "nama": "SHAKA MAHARDIKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 364,
    "nama": "TITANIA ZAHRA SULISTIO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 365,
    "nama": "TYAS AYU LISTYANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 366,
    "nama": "ZAMMIRA AMALYA SITUMORANG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 367,
    "nama": "ZIANDRU ATHARRAZKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V A"
  },
  {
    "id": 368,
    "nama": "ANDI RAYYAN ATHALLA AMRY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 369,
    "nama": "ARKHAN SALIM HAMIZAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 370,
    "nama": "ATHALLA RAZQA ANANTA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 371,
    "nama": "AYYASY DIPTA MULYADI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 372,
    "nama": "AZWA ISLAMIY ADDINA BALQIS",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 373,
    "nama": "BALQIS ADZRA LATHIFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 374,
    "nama": "CATALEYA RANIAH MAHENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 375,
    "nama": "DAVINA AULIA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 376,
    "nama": "ELVIRA ANINDITA SHANUM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 377,
    "nama": "EMIR CASSIDY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 378,
    "nama": "FRONTNESS ALTHAF FARRAS",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 379,
    "nama": "GISELLE OLIVIA JASMINE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 380,
    "nama": "HABIBIE HAZIQ PRAHANDHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 381,
    "nama": "KANZ GAOZHAN ALMAIR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 382,
    "nama": "KENZIE YAFIQ HAMIZAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 383,
    "nama": "KHAYSA YUMNA ALFATHUNNISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 384,
    "nama": "KIRANA AULIA MYSHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 385,
    "nama": "MARITZA FIKRIA NISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 386,
    "nama": "MUHAMMAD JIBRIL FAUZI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 387,
    "nama": "NADHIFA RAMADHANI AULIANNISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 388,
    "nama": "NADYA PUTRI ROSELIA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 389,
    "nama": "NAUFAL AZRI HILMAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 390,
    "nama": "RANIA SHALIHATUNNISA YUSUF",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 391,
    "nama": "RAYY AR RAZI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 392,
    "nama": "SABIL RASYAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 393,
    "nama": "ZEVANNA ALISYA HARTANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 394,
    "nama": "ZHAAFIRAH AUDREY SALSALITA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V B"
  },
  {
    "id": 395,
    "nama": "AFIQAH SHAKILA AZ ZAHRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 396,
    "nama": "ALEXY MATTHEW MARLEN S.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 397,
    "nama": "ALFARIZI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 398,
    "nama": "ALIFIANDRA PRAMUDYA BRATAJAYA SETIANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 399,
    "nama": "ALLINDA RAJAB HUTAGALUNG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 400,
    "nama": "ARINI KHAYYARA MARYAM",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 401,
    "nama": "ARKAFIAH RIZQINA BAHRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 402,
    "nama": "AVRILLA HAFSAH ROSALINE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 403,
    "nama": "BILAL ALFA RIZKY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 404,
    "nama": "FATIMAH KHOIRUNNISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 405,
    "nama": "GHANIYA ANIQA JASMINE",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 406,
    "nama": "GHANTARI SATYA MAHICA M.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 407,
    "nama": "HENI NATASHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 408,
    "nama": "HUSAIN ZULFAN HANIF",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 409,
    "nama": "JARVIS EGAN NDANA NUNUHITU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 410,
    "nama": "LATIFAH SRI ANISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 411,
    "nama": "LEONARD BERYL JONATHAN KARUWAL",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 412,
    "nama": "MEDINA PUTI SAFARAS",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 413,
    "nama": "MUHAMMAD ALFATIH SATWIKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 414,
    "nama": "MYIESHA ANDITA FALISHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 415,
    "nama": "NAUFAL MAHARDIKA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 416,
    "nama": "PASKAH PARMONANGAN GAJAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 417,
    "nama": "RAYA PRICILLYA RAMADHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 418,
    "nama": "VARISHA ADEILLA BRIANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 419,
    "nama": "VIOLA SYAFIA AZKADINA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 420,
    "nama": "WISNU PRANAJA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 421,
    "nama": "ZAFRAN ALVARO KURNIAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS V C"
  },
  {
    "id": 422,
    "nama": "ABIANDRA AKHDAN SHIRAZ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 423,
    "nama": "ADITYA HAMIZAN FADLI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 424,
    "nama": "ALIFIA KAYLA AZZAHRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 425,
    "nama": "ANASTASIA VALENCIA SAPUTRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 426,
    "nama": "ANISA NUR PELANGI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 427,
    "nama": "BALQIS SALSABILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 428,
    "nama": "CAESAR NOVEALARDO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 429,
    "nama": "CARISSA ALYA SUHARTONO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 430,
    "nama": "FATHAN ATHARI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 431,
    "nama": "GWEN ARACHEL FARANISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 432,
    "nama": "HAAGALFY HAYDAR AL - GOZALY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 433,
    "nama": "HAFIZH ANINDITO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 434,
    "nama": "HILAIFAH KHAUMI ROMANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 435,
    "nama": "HUSAIN ZABRAN SYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 436,
    "nama": "JANICE KAORI ALANNA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 437,
    "nama": "KAIZHI ALMER ARFINO SANTOSO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 438,
    "nama": "KANAKA MADA ANINDYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 439,
    "nama": "KAYLA AQILA CHIYANUMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 440,
    "nama": "KAYLA ATTAYA BURHANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 441,
    "nama": "KENZA JUNIOR EFFENDY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 442,
    "nama": "KENZIO AUFAR ZYANDRU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 443,
    "nama": "KHAIRA ADZKIYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 444,
    "nama": "NADA FAJRIA KHAIRINA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 445,
    "nama": "NATHAN ADHYASTA PRASAJA IZZ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 446,
    "nama": "NAYLA HAFIZAH SUPRIADI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 447,
    "nama": "NINDYA SABINE AMALIA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 448,
    "nama": "RADHIN ALAUNA FEBRIANDA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 449,
    "nama": "RAISSA NARAYA ASYILA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 450,
    "nama": "RATU KEISYA PRASETYO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 451,
    "nama": "REAGAN RAJENDRA ARAJNA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI A"
  },
  {
    "id": 452,
    "nama": "ABDULLAH BAGIR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 453,
    "nama": "ADLI FALAH YUSEN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 454,
    "nama": "ANINDITA CARISSA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 455,
    "nama": "AQSA RAMADHANY SHAREEN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 456,
    "nama": "BAGAS PUTRA SOFYAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 457,
    "nama": "CALVIN ILHAM EKA PRATAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 458,
    "nama": "DANISH BASYAR AL MUNAWWAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 459,
    "nama": "DIANDRA AUFAA QIANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 460,
    "nama": "EARLYTA ARSYIFA SALSABILA LAITAR",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 461,
    "nama": "HAFIDZ ARDIAZ PRATAMA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 462,
    "nama": "IRDINA BATRISYA GONDANI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 463,
    "nama": "IRFA HIBRIA OKTARISA PUTRI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 464,
    "nama": "KAYLA KHAIRUNNISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 465,
    "nama": "KEEANU ATHARRAZKA FAIZAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 466,
    "nama": "KENZI JUNIOR EFFENDY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 467,
    "nama": "MALKA ABIDIN CALIEF",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 468,
    "nama": "MEISYA PUTRI KURNIAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 469,
    "nama": "MUHAMMAD BAYU MAULANA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 470,
    "nama": "MUHAMMAD RASYAD",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 471,
    "nama": "NADHIRA PUTRI ANDINI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 472,
    "nama": "NAFEEZA CHIARA ASVANIA G.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 473,
    "nama": "NAJWA ADELIA QAIREEN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 474,
    "nama": "NAUFAL GIBRAN ERMANSYAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 475,
    "nama": "NINDYA PUTRI RAMADHANY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 476,
    "nama": "NINO ADYATAMA PRASRAYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 477,
    "nama": "RAYRA INTAN KHANISA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 478,
    "nama": "RESUL RAHMAT SADLI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 479,
    "nama": "RIANDRA ZAIDAN ANDRIANTO",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 480,
    "nama": "RYUGA GHANY AL FATHON",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 481,
    "nama": "SYAQUILLA EMILY RAMADHANIZ P.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI B"
  },
  {
    "id": 482,
    "nama": "AISYAH AZZALFA RIFAI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 483,
    "nama": "ALBIRUNI REAN SETIAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 484,
    "nama": "ALISHA KHAIRA DEWI",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 485,
    "nama": "ALIYANDRA SULTAN FAHREZA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 486,
    "nama": "AQEELA HUMAIRA HARDY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 487,
    "nama": "ARSAKHA RAMADILA GUNAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 488,
    "nama": "DEVANO RAJA MAHESYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 489,
    "nama": "DHITO JANUARDI BERUTU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 490,
    "nama": "DIANDRA KANAYA DYTHA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 491,
    "nama": "DWI WINARNI NAPITUPULU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 492,
    "nama": "FERREL SETIAWAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 493,
    "nama": "FRISTAN BAYU PRATAMA SARAGIH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 494,
    "nama": "KEANU GIBRAN SATRIO IRSHADEVAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 495,
    "nama": "KHUMAYRA LAURA ADITYA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 496,
    "nama": "KIKANDRYA SYAILENDRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 497,
    "nama": "LOVELEEN SAFA MAULIDDYNA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 498,
    "nama": "MAISYA AQILA HAQ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 499,
    "nama": "MIKA ABINAYA AGIFA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 500,
    "nama": "NADA RAFIDAH KHALISHAH",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 501,
    "nama": "NETANAEL SIHOTANG",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 502,
    "nama": "RAGIL NUGROHO PUTRA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 503,
    "nama": "RAYMOND ANDIKA YEREMIA S.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 504,
    "nama": "RHEVA RAMADHINA DAULAY",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 505,
    "nama": "SANDRO GILANG PANGESTU",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 506,
    "nama": "SEAN EFHIFANIAS KRISTINA W.",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 507,
    "nama": "SITI RISYDA HUWAIDA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 508,
    "nama": "SOPHIA HARMONI MALIQ",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 509,
    "nama": "THAMPANI SEPHAN PUTRA ABIDIN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 510,
    "nama": "YOHANES KARL SACHAEL HARIANJA",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Laki-laki",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  },
  {
    "id": 511,
    "nama": "ZEFANYA DIRAMOTHY SIAGIAN",
    "nisn": "0000000000",
    "tempat_lahir": null,
    "tanggal_lahir": null,
    "jenis_kelamin": "Perempuan",
    "satuan_pendidikan": "SD S SEKAR ADI",
    "kelas": "KELAS VI C"
  }
];
