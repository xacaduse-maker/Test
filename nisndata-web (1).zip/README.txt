CARA MENGAKTIFKAN QR CODE AGAR MENGARAH KE HALAMAN WEB
=======================================================

Saat ini QR code di setiap kartu siswa mengarah ke alamat placeholder:
  https://ganti-dengan-domain-anda.com/siswa/{id}.html

Supaya QR benar-benar bisa dipindai dari HP dan langsung membuka
halaman kartu siswa yang sesuai, ikuti 2 langkah ini:

1. HOST situs ini ke internet (pilih salah satu):
   - Domain/hosting sendiri (upload seluruh folder ini via cPanel/FTP)
   - GitHub Pages (gratis): buat repo baru, upload semua isi folder ini,
     aktifkan Pages di Settings > Pages. Alamatnya akan berbentuk:
     https://namaakun.github.io/nama-repo
   - Netlify (gratis): drag & drop folder ini di app.netlify.com/drop

2. EDIT satu file saja: assets/config.js
   Ganti baris:
     const SITE_BASE_URL = "https://ganti-dengan-domain-anda.com";
   dengan alamat situs Anda yang sebenarnya, tanpa tanda "/" di akhir.
   Contoh:
     const SITE_BASE_URL = "https://sekaradi.github.io/kartu-siswa";

Setelah file assets/config.js diubah dan diupload ulang, SELURUH 511
QR code di setiap halaman kartu siswa akan otomatis mengarah ke
halaman yang benar — tidak perlu generate ulang halaman satu per satu,
karena QR code dibuat secara dinamis oleh browser saat halaman dibuka.

CATATAN: Selama assets/config.js masih berisi alamat placeholder di atas,
QR code akan tetap bisa dipindai tapi akan mengarah ke alamat yang belum
aktif (browser HP akan menampilkan halaman tidak ditemukan).
